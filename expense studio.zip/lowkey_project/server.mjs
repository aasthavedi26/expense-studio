import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, 'public');
const port = process.env.PORT || 3000;

const mime = { '.html':'text/html; charset=utf-8', '.js':'text/javascript', '.css':'text/css', '.json':'application/json', '.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' };

const server = http.createServer((req, res) => {
  if (req.url === '/api/ai' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      res.writeHead(200, {'Content-Type':'application/json'});
      res.end(JSON.stringify({ok:false, error:'No AI backend configured. The dashboard will use its built-in local mode.'}));
    });
    return;
  }

  let urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
  if (urlPath === '/') urlPath = '/index.html';
  if (urlPath === '/dashboard') urlPath = '/dashboard.html';
  if (urlPath === '/login' || urlPath === '/signup' || urlPath === '/auth') urlPath = '/auth.html';
  const file = path.normalize(path.join(publicDir, urlPath));
  if (!file.startsWith(publicDir)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, {'Content-Type': mime[path.extname(file)] || 'application/octet-stream'});
    res.end(data);
  });
});

server.listen(port, () => console.log(`Expense Studio running at http://localhost:${port}`));
