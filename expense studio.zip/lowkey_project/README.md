# Expense Studio Expense Studio

## Run with npm

```bash
npm start
```

Open **http://localhost:3000/**.

## User flow

1. Landing page: `/`
2. Click **Start tracking** / CTA
3. Sign up or log in: `/auth.html`
4. Successful authentication opens `/dashboard.html`
5. Dashboard data is stored in browser localStorage and can be exported to Excel.
6. Use **Log out** in the dashboard to return to the login page.

This local demo authentication is intentionally browser-only and is not production security.
